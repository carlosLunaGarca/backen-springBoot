import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-libros-user',
  templateUrl: './libros-user.component.html',
  styleUrls: ['./libros-user.component.css']
})
export class LibrosUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
