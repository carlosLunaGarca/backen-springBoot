import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-libros-admin',
  templateUrl: './libros-admin.component.html',
  styleUrls: ['./libros-admin.component.css']
})
export class LibrosAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
