export class libro{
nombre:string;
autor:string;
categoria:string;
cant:number;
disp:number;
tarifa:number;
}