export class usuario{
    id:number;
	Nombre:string;
    email:string;
	pass:string;
    roll:boolean;
	sesion:boolean;
    }