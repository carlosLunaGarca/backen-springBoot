package co.com.gm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControlClientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
