package co.com.gm.Repositoris;
import org.springframework.data.repository.CrudRepository;
import co.com.gm.Models.LibroModel;
public interface LibroRepository extends CrudRepository<LibroModel,Long> {
   
}
